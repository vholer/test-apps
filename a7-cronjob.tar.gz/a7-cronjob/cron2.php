<?php

$host = gethostname();
echo "DEBUG: Job started on ${host}\n";

exit(66);
