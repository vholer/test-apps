<?php echo "PHPower to the PHPeople";
